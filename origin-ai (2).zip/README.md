# Origin AI

An autonomous AI system with multi-agent architecture and LLM orchestration.